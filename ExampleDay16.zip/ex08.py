'''
다중 상속
- 여러개의 클래스로부터 기능을 상속받는것

다중상속을 지원하는 언어: c++, python
다중상속을 지원하지 않는 언어: java
단, java는 인터페이스 다중상속은 가능

class a
class b
class c(a, b) (class c가 a,b를 상속받음_)

'''